/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Allow images from Meta CDN (profile pictures etc.)
  images: {
    domains: ['scontent.xx.fbcdn.net'],
  },
}

module.exports = nextConfig
