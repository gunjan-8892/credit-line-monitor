import { useSession, signOut } from 'next-auth/react'
import { useRouter } from 'next/router'
import { useEffect, useState, useRef, useCallback } from 'react'

const PER_PAGE = 25

// ─── Helpers ────────────────────────────────────────────────────────────────
function getTodayStr() {
  const d = new Date()
  return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`
}

function fmtTime(isoStr) {
  if (!isoStr) return ''
  const d = new Date(isoStr)
  return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Calcutta' }) + ' IST'
}

function dateVal(dateStr) {
  if (!dateStr || dateStr === '-') return 0
  const [m, d, y] = dateStr.split('/')
  return new Date(+y || 2026, +m - 1, +d).getTime()
}

function dayAge(dateStr) {
  if (!dateStr || dateStr === '-') return -1
  const [m, d, y] = dateStr.split('/')
  const then = new Date(+y || 2026, +m - 1, +d)
  return Math.round((Date.now() - then.getTime()) / 86400000)
}

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
}

// ─── Toast ───────────────────────────────────────────────────────────────────
function useToast() {
  const [toasts, setToasts] = useState([])
  const add = useCallback((icon, title, desc, dur = 4000) => {
    const id = Date.now()
    setToasts(prev => [...prev, { id, icon, title, desc }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), dur)
  }, [])
  return { toasts, toast: add }
}

// ─── Bar Chart (canvas) ───────────────────────────────────────────────────────
function BarChart({ byDate }) {
  const ref = useRef(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return

    const entries = Object.entries(byDate || {})
      .sort(([a], [b]) => dateVal(a) - dateVal(b))
      .slice(-10)
      .map(([k, v]) => [k.slice(0, k.lastIndexOf('/')), v])

    if (!entries.length) return

    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    const ctx = canvas.getContext('2d')
    ctx.scale(dpr, dpr)

    const W = rect.width, H = rect.height
    const maxVal = Math.max(...entries.map(e => +e[1]), 1)
    const pad = { l: 40, r: 8, t: 12, b: 28 }
    const plotW = W - pad.l - pad.r, plotH = H - pad.t - pad.b
    const barW = plotW / entries.length * 0.6
    const gap = plotW / entries.length

    const s = getComputedStyle(document.documentElement)
    const accent = s.getPropertyValue('--chart-bar').trim() || '#3B82F6'
    const muted = s.getPropertyValue('--muted').trim() || '#6878A8'
    const borderCol = s.getPropertyValue('--border').trim() || '#252B3E'

    ;[0, 0.25, 0.5, 0.75, 1].forEach(f => {
      const y = pad.t + plotH * (1 - f)
      ctx.strokeStyle = borderCol
      ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(pad.l, y); ctx.lineTo(pad.l + plotW, y); ctx.stroke()
      ctx.fillStyle = muted
      ctx.font = `10px 'JetBrains Mono', monospace`
      ctx.textAlign = 'right'
      ctx.fillText(Math.round(maxVal * f), pad.l - 4, y + 3.5)
    })

    entries.forEach(([label, val], i) => {
      const v = +val
      const x = pad.l + i * gap + (gap - barW) / 2
      const h = (v / maxVal) * plotH
      const y = pad.t + plotH - h
      ctx.fillStyle = accent + '33'
      ctx.beginPath()
      if (ctx.roundRect) ctx.roundRect(x, y, barW, h, 3)
      else ctx.rect(x, y, barW, h)
      ctx.fill()
      ctx.fillStyle = accent
      ctx.fillRect(x, y, barW, 3)
      ctx.fillStyle = muted
      ctx.font = `10px 'Inter', sans-serif`
      ctx.textAlign = 'center'
      ctx.fillText(label, x + barW / 2, H - 8)
      if (v > 5) {
        ctx.fillStyle = accent
        ctx.font = `bold 10px 'JetBrains Mono', monospace`
        ctx.fillText(v, x + barW / 2, y - 4)
      }
    })
  }, [byDate])

  return <canvas ref={ref} style={{ width: '100%', height: '160px' }} />
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function Dashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const { toasts, toast } = useToast()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [syncing, setSyncing] = useState(false)
  const [theme, setTheme] = useState('system')
  // Table state
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [sortCol, setSortCol] = useState('date')
  const [sortDir, setSortDir] = useState(-1)
  const [page, setPage] = useState(1)

  const today = getTodayStr()

  // Auth redirect
  useEffect(() => {
    if (status === 'unauthenticated') router.replace('/login')
  }, [status, router])

  // Fetch data
  const fetchData = useCallback(async (showToast = false) => {
    setSyncing(true)
    if (showToast) toast('🔄', 'Refreshing…', 'Fetching latest from Meta API')
    try {
      const res = await fetch('/api/partners')
      if (!res.ok) {
        const json = await res.json()
        throw new Error(json.error || `HTTP ${res.status}`)
      }
      const json = await res.json()
      setData(json)
      setError(null)
      if (showToast) toast('✅', 'Data refreshed', `${json.total} partners loaded`)
    } catch (e) {
      setError(e.message)
      if (showToast) toast('❌', 'Sync failed', e.message)
    } finally {
      setLoading(false)
      setSyncing(false)
    }
  }, [toast])

  useEffect(() => {
    if (status === 'authenticated') fetchData()
  }, [status, fetchData])

  // Theme toggle
  const toggleTheme = () => {
    const next = theme === 'dark' ? 'light' : 'dark'
    setTheme(next)
    document.documentElement.setAttribute('data-theme', next)
  }

  // Table helpers
  const partners = data?.partners || []
  const filtered = partners.filter(p => {
    const q = search.toLowerCase()
    const matchQ = !q || p.name.toLowerCase().includes(q) || p.bm.includes(q)
    const matchF =
      filter === 'all' ? true
      : filter === 'full' ? p.type === 'Full'
      : filter === 'partial' ? p.type === 'Partial'
      : filter === 'pending' ? p.type === 'Pending'
      : filter === 'recent' ? p.date === today
      : true
    return matchQ && matchF
  }).sort((a, b) => {
    let va = sortCol === 'date' ? dateVal(a.date)
      : sortCol === 'name' ? a.name.toLowerCase()
      : a[sortCol] || ''
    let vb = sortCol === 'date' ? dateVal(b.date)
      : sortCol === 'name' ? b.name.toLowerCase()
      : b[sortCol] || ''
    return va < vb ? sortDir : va > vb ? -sortDir : 0
  })

  const totalPages = Math.ceil(filtered.length / PER_PAGE)
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE)

  const handleSort = col => {
    if (sortCol === col) setSortDir(d => d * -1)
    else { setSortCol(col); setSortDir(-1) }
    setPage(1)
  }
  const handleFilter = f => { setFilter(f); setPage(1) }
  const handleSearch = e => { setSearch(e.target.value); setPage(1) }

  // CSV download
  const downloadCSV = () => {
    const rows = filtered
    const header = ['BM Name', 'BM ID', 'Credit Limit', 'Type', 'Date']
    const lines = [
      header.join(','),
      ...rows.map(p =>
        [p.name, p.bm, p.limit || '', p.type, p.date || '']
          .map(v => `"${String(v).replace(/"/g, '""')}"`)
          .join(',')
      ),
    ]
    const blob = new Blob([lines.join('\r\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `credit-line-partners-${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast('✅', 'CSV downloaded', `${rows.length} rows`)
  }

  if (status === 'loading' || (status === 'authenticated' && loading && !data)) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg)' }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <div className="spinner" style={{ width: 32, height: 32 }} />
          <div style={{ color: 'var(--muted)', fontSize: 13 }}>Loading partner data…</div>
        </div>
      </div>
    )
  }

  if (status !== 'authenticated') return null

  const d = data || {}
  const todayCount = (d.byDate || {})[today] || 0

  return (
    <>
      {/* Toast container */}
      <div style={{ position: 'fixed', bottom: 24, right: 24, zIndex: 9999, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {toasts.map(t => (
          <div key={t.id} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 8, padding: '12px 16px', boxShadow: 'var(--shadow-lg)', fontSize: 13, maxWidth: 320, animation: 'slideIn .2s ease', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
            <span style={{ fontSize: 16 }}>{t.icon}</span>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 2 }}>{t.title}</div>
              {t.desc && <div style={{ fontSize: 12, color: 'var(--muted)' }}>{t.desc}</div>}
            </div>
          </div>
        ))}
      </div>

      {/* Header */}
      <header style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 56, position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg viewBox="0 0 24 24" fill="white" width="18" height="18"><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 14v-4H7l5-8v4h4l-5 8z" /></svg>
          </div>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, letterSpacing: '-0.2px' }}>Credit Line Monitor</div>
            <div style={{ fontSize: 12, color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace' }}>Meta BM Partner Allocations · Blitzscale</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: error ? 'var(--danger)' : 'var(--success)', boxShadow: error ? 'none' : '0 0 0 3px var(--success-bg)', animation: error ? 'none' : 'pulse 2s infinite' }} />
          <span style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace' }}>{error ? 'Error' : 'Live'}</span>
          {d.lastSync && (
            <span style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'JetBrains Mono, monospace' }}>
              Synced {fmtTime(d.lastSync)}
            </span>
          )}
          <button className="hdr-btn" onClick={() => fetchData(true)} disabled={syncing}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={syncing ? { animation: 'spin .8s linear infinite' } : {}}>
              <polyline points="23 4 23 10 17 10" /><polyline points="1 20 1 14 7 14" />
              <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
            </svg>
            Sync Now
          </button>
          <button className="hdr-btn" onClick={toggleTheme}>◑</button>
          <button className="hdr-btn" onClick={() => signOut({ callbackUrl: '/login' })} title={`Sign out (${session.user?.email})`}>
            <img src={session.user?.image} alt="" style={{ width: 18, height: 18, borderRadius: '50%' }} />
            Sign out
          </button>
        </div>
      </header>

      {/* Main */}
      <div style={{ maxWidth: 1400, margin: '0 auto', padding: '24px 24px', display: 'flex', flexDirection: 'column', gap: 20 }}>

        {/* Error banner */}
        {error && (
          <div style={{ background: 'var(--danger-bg)', border: '1px solid var(--danger)', color: 'var(--danger)', borderRadius: 10, padding: '12px 18px', fontSize: 13 }}>
            <strong>Meta API error:</strong> {error}
          </div>
        )}

        {/* KPI Row */}
        <div className="kpi-row">
          <KPICard cls="k-total" label="Total Partners" value={d.total ?? '—'} sub="All BM allocations"
            badge={{ text: todayCount > 0 ? `+${todayCount} today` : 'All time', color: 'up' }} />
          <KPICard cls="k-full" label="Full Access" value={d.fullCount ?? '—'} sub="Shared full credit line"
            badge={{ text: d.total ? `${(d.fullCount / d.total * 100).toFixed(1)}% of partners` : '', color: 'up' }} />
          <KPICard cls="k-partial" label="Partial Allocation" value={d.partialCount ?? '—'} sub="Fixed $ limit set"
            badge={{ text: 'Needs review', color: 'warn' }} />
          <KPICard cls="k-pending" label="Pending Approval" value={d.pendingCount ?? '—'} sub="Awaiting grant"
            badge={{ text: 'Action required', color: 'alert' }} />
          <KPICard cls="k-credit" label="Credit Line Total" value={d.creditLine ? `$${(d.creditLine / 1e6).toFixed(2)}M` : '—'} sub="Shared across full-access BMs"
            badge={{ text: d.creditLine ? `$${d.creditLine.toLocaleString('en-US', { minimumFractionDigits: 2 })}` : '', color: 'warn' }} />
        </div>

        {/* Mid row */}
        <div className="mid-row">
          {/* Trigger Alerts */}
          <div className="panel">
            <div className="panel-header">
              <div className="panel-title"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--danger)', display: 'inline-block' }} />Trigger Alerts</div>
              <span style={{ fontSize: 11, color: 'var(--muted)' }}>4 active rules</span>
            </div>
            <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              <TriggerItem icon="🟠" color="pending" title="Pending Approval"
                desc={`${d.pendingCount || 0} partners have requested access but are awaiting approval.`}
                badge={`${d.pendingCount || 0} BMs`} badgeCls="ts-pending" />
              <TriggerItem icon="🟣" color="partial" title="Partial Allocation"
                desc={`${d.partialCount || 0} partners have fixed-cap allocations, not full shared access.`}
                badge={`${d.partialCount || 0} BMs`} badgeCls="ts-warn" />
              <TriggerItem icon="🔵" color="info" title="New Partners Today"
                desc={`${todayCount} partners were granted access today. Verify onboarding is complete.`}
                badge={`${todayCount} today`} badgeCls="ts-active" />
              <TriggerItem icon="🟡" color="warning" title="Auto-Sync"
                desc="Click Sync Now to pull the latest data from Meta Graph API on demand."
                badge="On demand" badgeCls="ts-active" />
            </div>
          </div>

          {/* Chart + Partials */}
          <div className="panel">
            <div className="panel-header">
              <div className="panel-title"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', display: 'inline-block' }} />Partners Added by Day</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--muted)' }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: 'var(--chart-bar)', display: 'inline-block' }} />New grants
              </div>
            </div>
            <div style={{ padding: '16px 20px 8px' }}>
              <BarChart byDate={d.byDate || {}} />
            </div>
            <div style={{ padding: '0 20px 4px', fontSize: 11, fontWeight: 600, color: 'var(--muted)', letterSpacing: '.5px', textTransform: 'uppercase' }}>
              Partial Allocation Partners
            </div>
            <div style={{ padding: '8px 16px 16px', display: 'flex', flexDirection: 'column', gap: 8 }}>
              {(d.partialPartners || []).length === 0
                ? <div style={{ fontSize: 12, color: 'var(--muted)', padding: 8 }}>No partial partners</div>
                : (d.partialPartners || []).map(p => (
                  <div key={p.bm} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px', borderRadius: 8, border: '1px solid var(--partial-bg)', background: 'var(--surface2)' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 500, fontSize: 13 }}>{p.name}</div>
                      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--muted)' }}>{p.bm}</div>
                    </div>
                    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, fontWeight: 600, color: 'var(--partial)' }}>
                      {(p.limit || '').replace(' allocated', '')}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="table-panel">
          <div className="table-toolbar">
            <span style={{ fontWeight: 600, fontSize: 13, flex: 1 }}>All Partner BM Accounts</span>
            <input className="search-box" type="text" placeholder="Search name or BM ID…" value={search} onChange={handleSearch} />
            {['all', 'full', 'partial', 'pending', 'recent'].map(f => (
              <button key={f} className={`filter-btn${filter === f ? ' active' : ''}`} onClick={() => handleFilter(f)}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
            <span className="count-badge">{filtered.length}</span>
            <button className="hdr-btn" onClick={downloadCSV}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              CSV
            </button>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontVariantNumeric: 'tabular-nums' }}>
              <thead>
                <tr>
                  {[['name', 'BM Name'], ['bm', 'BM ID'], ['limit', 'Credit Limit'], ['type', 'Type'], ['date', 'Date Updated']].map(([col, label]) => (
                    <th key={col} onClick={() => handleSort(col)} className={`th${sortCol === col ? ' sorted' : ''}`}>
                      {label} <span>{sortCol === col ? (sortDir === -1 ? '↓' : '↑') : '↕'}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paginated.length === 0 ? (
                  <tr><td colSpan={5} style={{ textAlign: 'center', padding: 40, color: 'var(--muted)' }}>No partners match</td></tr>
                ) : paginated.map((p, i) => {
                  const age = dayAge(p.date)
                  return (
                    <tr key={p.bm + i}>
                      <td style={{ fontWeight: 500, padding: '11px 16px', fontSize: 13 }}>{p.name}</td>
                      <td style={{ padding: '11px 16px' }}>
                        <a href={`https://business.facebook.com/overview?business_id=${p.bm}`} target="_blank" rel="noreferrer"
                          style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'var(--accent)' }}>
                          {p.bm}
                        </a>
                      </td>
                      <td style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 12, padding: '11px 16px', color: p.type === 'Partial' ? 'var(--partial)' : p.type === 'Pending' ? 'var(--pending)' : 'var(--text)', fontWeight: p.type !== 'Full' ? 600 : 400, fontStyle: p.type === 'Pending' ? 'italic' : 'normal' }}>
                        {p.limit}
                      </td>
                      <td style={{ padding: '11px 16px' }}>
                        <span className={`badge badge-${p.type.toLowerCase()}`}>{p.type}</span>
                      </td>
                      <td style={{ padding: '11px 16px', fontFamily: 'JetBrains Mono, monospace', fontSize: 12, color: age === 0 ? 'var(--success)' : age > 30 ? 'var(--warning)' : 'var(--muted)' }}>
                        {p.date === '-' ? <span style={{ color: 'var(--pending)', fontStyle: 'italic' }}>Pending</span> : p.date}
                        {age === 0 && <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--success)', marginLeft: 4 }}>NEW</span>}
                        {age > 30 && <span style={{ fontSize: 10, fontWeight: 700, color: 'var(--warning)', marginLeft: 4 }}>{age}d</span>}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          <div style={{ padding: '12px 20px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: 12, color: 'var(--muted)' }}>
            <span>
              {filtered.length > 0
                ? `Showing ${(page - 1) * PER_PAGE + 1}–${Math.min(page * PER_PAGE, filtered.length)} of ${filtered.length}`
                : 'No results'}
            </span>
            {totalPages > 1 && (
              <div style={{ display: 'flex', gap: 4 }}>
                <button className="page-btn" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}>‹</button>
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(p => p === 1 || p === totalPages || Math.abs(p - page) <= 1)
                  .reduce((acc, p, i, arr) => {
                    if (i > 0 && p - arr[i - 1] > 1) acc.push('…')
                    acc.push(p)
                    return acc
                  }, [])
                  .map((p, i) => p === '…'
                    ? <span key={i} className="page-btn" style={{ cursor: 'default', opacity: .4 }}>…</span>
                    : <button key={p} className={`page-btn${p === page ? ' active' : ''}`} onClick={() => setPage(p)}>{p}</button>
                  )
                }
                <button className="page-btn" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}>›</button>
              </div>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .hdr-btn { border: 1px solid var(--border); background: var(--surface2); color: var(--text); border-radius: 6px; padding: 5px 10px; cursor: pointer; font-size: 12px; font-family: 'Inter', sans-serif; transition: all .15s; display: flex; align-items: center; gap: 5px; }
        .hdr-btn:hover { border-color: var(--accent); color: var(--accent); }
        .hdr-btn:disabled { opacity: .5; cursor: default; }
        .kpi-row { display: grid; grid-template-columns: repeat(5, 1fr); gap: 14px; }
        .mid-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .panel { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; box-shadow: var(--shadow); overflow: hidden; }
        .panel-header { padding: 14px 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; }
        .panel-title { font-weight: 600; font-size: 13px; display: flex; align-items: center; gap: 8px; }
        .table-panel { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; box-shadow: var(--shadow); overflow: hidden; }
        .table-toolbar { padding: 14px 20px; border-bottom: 1px solid var(--border); display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .search-box { border: 1px solid var(--border); background: var(--surface2); color: var(--text); border-radius: 7px; padding: 7px 12px; font-family: 'Inter', sans-serif; font-size: 13px; outline: none; width: 220px; transition: border-color .15s; }
        .search-box::placeholder { color: var(--muted); }
        .search-box:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-glow); }
        .filter-btn { border: 1px solid var(--border); background: var(--surface2); color: var(--text); border-radius: 7px; padding: 6px 12px; font-family: 'Inter', sans-serif; font-size: 12px; cursor: pointer; transition: all .15s; }
        .filter-btn.active { border-color: var(--accent); color: var(--accent); background: var(--accent-glow); }
        .count-badge { background: var(--accent-glow); color: var(--accent); border-radius: 20px; padding: 2px 10px; font-size: 12px; font-weight: 600; }
        thead th { padding: 10px 16px; text-align: left; font-size: 11px; font-weight: 600; color: var(--muted); letter-spacing: .5px; text-transform: uppercase; background: var(--surface2); border-bottom: 1px solid var(--border); cursor: pointer; user-select: none; white-space: nowrap; }
        .th:hover { color: var(--accent); }
        .th.sorted { color: var(--accent); }
        tbody tr { border-bottom: 1px solid var(--border); transition: background .1s; }
        tbody tr:last-child { border-bottom: none; }
        tbody tr:hover { background: var(--surface2); }
        .badge { display: inline-block; padding: 3px 9px; border-radius: 20px; font-size: 11px; font-weight: 600; white-space: nowrap; }
        .badge-full { background: var(--full-bg); color: var(--full); }
        .badge-partial { background: var(--partial-bg); color: var(--partial); }
        .badge-pending { background: var(--pending-bg); color: var(--pending); }
        .page-btn { border: 1px solid var(--border); background: var(--surface2); color: var(--text); border-radius: 5px; padding: 4px 9px; cursor: pointer; font-size: 12px; font-family: 'Inter', sans-serif; transition: all .15s; }
        .page-btn:hover, .page-btn.active { border-color: var(--accent); color: var(--accent); background: var(--accent-glow); }
        .page-btn:disabled { opacity: .4; cursor: default; }
        @media(max-width:1100px){.kpi-row{grid-template-columns:repeat(3,1fr)}}
        @media(max-width:900px){.kpi-row{grid-template-columns:repeat(2,1fr)}.mid-row{grid-template-columns:1fr}}
        @media(max-width:600px){.kpi-row{grid-template-columns:1fr};.main{padding:16px}}
      `}</style>
    </>
  )
}

// ─── Sub-components ───────────────────────────────────────────────────────────
function KPICard({ cls, label, value, sub, badge }) {
  const colors = { up: 'var(--success)', warn: 'var(--warning)', alert: 'var(--pending)' }
  const bgs = { up: 'var(--success-bg)', warn: 'var(--warning-bg)', alert: 'var(--pending-bg)' }
  return (
    <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: '18px 20px', boxShadow: 'var(--shadow)', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, borderRadius: '10px 10px 0 0', background: `var(--${cls.replace('k-', '')}, var(--accent))` }} />
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--muted)', letterSpacing: '.6px', textTransform: 'uppercase', marginBottom: 8 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.8px', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 6 }}>{sub}</div>
      {badge?.text && (
        <div style={{ display: 'inline-flex', alignItems: 'center', fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 20, marginTop: 8, background: bgs[badge.color], color: colors[badge.color] }}>
          {badge.text}
        </div>
      )}
    </div>
  )
}

function TriggerItem({ icon, color, title, desc, badge, badgeCls }) {
  const bgMap = { pending: 'var(--pending-bg)', partial: 'var(--partial-bg)', info: 'var(--full-bg)', warning: 'var(--warning-bg)' }
  const clsMap = { 'ts-active': { bg: 'var(--success-bg)', color: 'var(--success)' }, 'ts-warn': { bg: 'var(--warning-bg)', color: 'var(--warning)' }, 'ts-alert': { bg: 'var(--danger-bg)', color: 'var(--danger)' }, 'ts-pending': { bg: 'var(--pending-bg)', color: 'var(--pending)' } }
  const bc = clsMap[badgeCls] || clsMap['ts-active']
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '12px 14px', borderRadius: 8, border: '1px solid transparent', transition: 'all .15s' }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, flexShrink: 0, background: bgMap[color] || 'var(--surface2)' }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 2 }}>{title}</div>
        <div style={{ fontSize: 12, color: 'var(--muted)', lineHeight: 1.4 }}>{desc}</div>
      </div>
      <div style={{ flexShrink: 0, padding: '3px 9px', borderRadius: 20, fontSize: 11, fontWeight: 600, alignSelf: 'flex-start', background: bc.bg, color: bc.color }}>{badge}</div>
    </div>
  )
}
