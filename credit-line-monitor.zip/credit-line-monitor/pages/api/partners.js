import { getServerSession } from 'next-auth/next'
import { authOptions } from './auth/[...nextauth]'
import { getCreditLineData } from '../../lib/meta'

/**
 * GET /api/partners
 *
 * Returns credit line partner data from Meta Graph API.
 * Requires a valid session (Google SSO).
 *
 * Query params:
 *   refresh=1  → bypass cache and force a fresh Meta API call
 */
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' })
  }

  // Auth gate
  const session = await getServerSession(req, res, authOptions)
  if (!session) {
    return res.status(401).json({ error: 'Unauthorized' })
  }

  try {
    const data = await getCreditLineData()

    // Cache-control: allow CDN/browser to cache for 5 minutes
    res.setHeader('Cache-Control', 's-maxage=300, stale-while-revalidate=60')
    return res.status(200).json(data)
  } catch (err) {
    console.error('[/api/partners]', err)
    return res.status(500).json({
      error: err.message || 'Failed to fetch partner data',
    })
  }
}
