import { signIn, useSession } from 'next-auth/react'
import { useRouter } from 'next/router'
import { useEffect } from 'react'

export default function LoginPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const error = router.query.error

  useEffect(() => {
    if (status === 'authenticated') {
      router.replace('/')
    }
  }, [status, router])

  if (status === 'loading') {
    return (
      <div className="auth-page">
        <div className="spinner" />
      </div>
    )
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28">
            <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1 14v-4H7l5-8v4h4l-5 8z" />
          </svg>
        </div>
        <h1 className="auth-title">Credit Line Monitor</h1>
        <p className="auth-sub">Blitzscale · Meta BM Partner Allocations</p>

        {error === 'AccessDenied' && (
          <div className="auth-error">
            Access denied. Only <strong>@blitzscale.co</strong> accounts are allowed.
          </div>
        )}

        {error && error !== 'AccessDenied' && (
          <div className="auth-error">
            Something went wrong. Please try again.
          </div>
        )}

        <button
          className="google-btn"
          onClick={() => signIn('google', { callbackUrl: '/' })}
        >
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z" />
            <path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17z" />
            <path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18z" />
            <path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.77 4.77 0 0 1 4.48-3.3z" />
          </svg>
          Sign in with Google
        </button>

        <p className="auth-note">@blitzscale.co accounts only</p>
      </div>

      <style>{`
        .auth-page {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          background: var(--bg);
          padding: 24px;
        }
        .auth-card {
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 16px;
          padding: 40px;
          width: 100%;
          max-width: 380px;
          box-shadow: var(--shadow-lg);
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 12px;
        }
        .auth-logo {
          width: 56px;
          height: 56px;
          background: var(--accent);
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          margin-bottom: 4px;
        }
        .auth-title {
          font-size: 22px;
          font-weight: 700;
          letter-spacing: -0.5px;
          color: var(--text);
          margin: 0;
        }
        .auth-sub {
          font-size: 13px;
          color: var(--muted);
          margin: 0;
          text-align: center;
        }
        .auth-error {
          width: 100%;
          background: var(--danger-bg);
          color: var(--danger);
          border: 1px solid var(--danger);
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13px;
          text-align: center;
          margin-top: 4px;
        }
        .google-btn {
          display: flex;
          align-items: center;
          gap: 10px;
          background: var(--surface);
          border: 1.5px solid var(--border);
          border-radius: 8px;
          padding: 11px 24px;
          font-size: 14px;
          font-weight: 500;
          color: var(--text);
          cursor: pointer;
          transition: all 0.15s;
          width: 100%;
          justify-content: center;
          margin-top: 8px;
          font-family: 'Inter', sans-serif;
        }
        .google-btn:hover {
          border-color: var(--accent);
          background: var(--surface2);
          box-shadow: 0 0 0 3px var(--accent-glow);
        }
        .auth-note {
          font-size: 11px;
          color: var(--muted);
          margin: 0;
          font-family: 'JetBrains Mono', monospace;
        }
        .spinner {
          width: 24px;
          height: 24px;
          border: 2px solid var(--border);
          border-top-color: var(--accent);
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  )
}
