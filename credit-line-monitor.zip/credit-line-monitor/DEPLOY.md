# Credit Line Monitor — Deployment Guide

## One-time setup (~20 min)

### 1. Google OAuth credentials

1. Open [console.cloud.google.com](https://console.cloud.google.com)
2. Create a project (or use an existing one)
3. Enable the **Google+ API** (APIs & Services → Library → search "Google+")
4. Go to **APIs & Services → Credentials → Create Credentials → OAuth 2.0 Client ID**
5. Application type: **Web application**
6. Add Authorized redirect URI:
   - For Vercel: `https://your-app.vercel.app/api/auth/callback/google`
   - For local dev: `http://localhost:3000/api/auth/callback/google`
7. Copy the **Client ID** and **Client Secret**

### 2. Meta System User token

1. Open [Meta Business Manager](https://business.facebook.com/settings/system-users)
2. Go to **Business Settings → System Users → Add**
3. Give it Admin role
4. Click **Generate New Token**, select your app, check these permissions:
   - `business_management`
   - `ads_management` (may be required for credit line endpoints)
5. Copy the long-lived token (it never expires)
6. Your **Business ID** is in Business Settings → Business Info

### 3. Deploy to Vercel (free)

```bash
# Install Vercel CLI
npm i -g vercel

# From the project folder
cd credit-line-monitor
npm install
vercel

# Follow prompts, then add environment variables:
vercel env add GOOGLE_CLIENT_ID
vercel env add GOOGLE_CLIENT_SECRET
vercel env add NEXTAUTH_SECRET          # run: openssl rand -hex 32
vercel env add NEXTAUTH_URL             # your production URL, e.g. https://credit-monitor.vercel.app
vercel env add META_ACCESS_TOKEN
vercel env add META_BUSINESS_ID
vercel env add ALLOWED_EMAIL_DOMAIN     # blitzscale.co
vercel env add CACHE_TTL_SECONDS        # 300

# Redeploy with env vars
vercel --prod
```

### 4. Local development

```bash
cp .env.example .env.local
# Fill in .env.local with real values
npm install
npm run dev
# Open http://localhost:3000
```

## Architecture

```
Browser → /login (Google SSO) → NextAuth → session cookie
                                              ↓
Dashboard → GET /api/partners → lib/meta.js → Meta Graph API
```

- **Auth**: NextAuth.js with Google provider, restricted to @blitzscale.co
- **Data**: Meta Graph API v20.0 — `/{businessId}/extendedcredits` → `/{creditId}/all_sharing_agreements`
- **Cache**: In-memory, 5-min TTL (resets on cold start; tune with CACHE_TTL_SECONDS)
- **Deploy**: Vercel (serverless, free tier handles this easily)

## Meta API endpoints used

```
GET /{META_BUSINESS_ID}/extendedcredits
  fields: id, credit_details, credit_type, credit_status, max_balance, balance

GET /{credit_id}/all_sharing_agreements
  fields: receiving_business{name,id}, credit_type, credit_amount,
          expiration_time, time_created, status
```

## Troubleshooting

| Error | Fix |
|---|---|
| `Access denied` on login | Email not @blitzscale.co, or Google OAuth not configured |
| `META_ACCESS_TOKEN and META_BUSINESS_ID must be set` | Add env vars and redeploy |
| `Meta API error: (#200) Not enough permission` | System User needs `business_management` permission |
| `No extended credits found` | System User may not have access to the credit line — add it in Business Settings |
| Data looks stale | Click "Sync Now" or reduce CACHE_TTL_SECONDS |
